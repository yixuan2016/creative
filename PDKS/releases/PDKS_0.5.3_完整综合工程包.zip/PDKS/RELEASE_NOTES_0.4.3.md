# PDKS 0.4.3 — Cross-Agent Skill Validation Edition

## Position

Still an experimental, transitional-stage Agent Skill development release. It is not a final personal digital foundation platform or a production service.

## Version matrix

- Runtime track: `0.4.3`
- Agent Skill: `0.3.3`
- PDKS Standard: `0.1.0` (unchanged)
- JSON Record Schema: `0.1.x` (unchanged)
- Ontology: `0.2.1` (frozen)
- Event Taxonomy: `0.1.0` (unchanged)

## Added

1. 12 synthetic work-context benchmark cases.
2. Cross-host execution protocol and host-run matrix.
3. 100-point human evaluation rubric with critical failure rules.
4. Candidate output contract for consistent result collection.
5. Structural evaluator for JSON Schema, record types, provenance, least privilege, uncertainty, identity and host capability declarations.
6. Regression tests for benchmark manifest and evaluator fixture.

## Not claimed

- No real second-host run is included in this release.
- No model ranking or cross-agent pass result is claimed.
- The evaluator is not an automated semantic judge.
- No real personal data, DingTalk connector, recorder integration, background capture, production consent service, or hosted memory service is included.

## Validation

Run:
```bash
python skills/pdks-personal-knowledge/scripts/validate_skill_stage.py --json
python -m unittest discover -s tests -v
python prototype/pdks_ontology_cli.py ontology-check
python skills/pdks-personal-knowledge/scripts/build_ontology_manifest.py --check
```

Cross-host protocol:
```bash
python skills/pdks-personal-knowledge/scripts/evaluate_benchmark.py --case C01-meeting-event-decision-action --candidate path/to/candidate.json
```

A machine pass is not a human semantic pass. Human review is required for every candidate run.
