# PDKS 0.5.2.1 — File Store Adapter Preview

Development stage: `transitional_skill_development`  
Maturity: Experimental / Preview

## Added
- `FileFirstVault` 0.1.0 reference adapter.
- `vault-init`, `vault-sync`, `vault-verify`, `vault-rebuild-index` CLI commands.
- Markdown + YAML Frontmatter knowledge-note projection.
- Immutable JSONL Source Asset / Evidence projection.
- SHA-256 content-addressed attachments and attachment index.
- Relative Markdown links from knowledge notes to source records, evidence and original attachments.
- `PDKS-MANIFEST.json` with portable-file size and SHA-256 checks.
- Rebuildable file-search SQLite index.
- User-edit conflict protection; generated notes do not silently overwrite edited Markdown.
- A generated synthetic PDKS Vault example suitable for opening in Obsidian.

## Validation
- Skill tests: 53 total, 52 passed, 1 skipped.
- Prototype tests: 33 total, 32 passed, 1 skipped.
- Runtime tests: 64 passed, including 7 File Store Adapter tests.
- Total: 150 tests, 148 passed, 2 skipped, 0 failed.
- Stage validator: 12/12.
- Ontology 0.2.1: 98/98 runtime term coverage.
- Ontology manifest check: 8 files valid.
- Python compile check: passed.
- CLI integration: init → capture → vault-init → vault-sync → vault-verify → vault-rebuild-index passed with synthetic data.

## Important limitations
- `vault-sync` is a one-way projection from the existing Runtime database.
- The operational CaptureRuntime database remains authoritative in this preview.
- No transactional outbox, live bidirectional sync, complete operational DB reconstruction, at-rest encryption, OS keychain, multi-device sync or native Node.js installer is delivered.
- Real DWS tenant delivery and Codex / WorkBuddy host validation remain unexecuted.
- Use synthetic or non-sensitive data only until security controls are implemented and reviewed.
