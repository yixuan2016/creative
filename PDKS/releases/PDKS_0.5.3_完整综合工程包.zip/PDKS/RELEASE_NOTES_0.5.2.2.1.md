# PDKS 0.5.2.2.1 — Agent-native Bootstrap Safety Patch

- PDKS track: 0.5.2.2 (no schema or ontology changes)
- Agent Bridge: 0.1.1
- Stage: `transitional_skill_development`
- Maturity: Experimental / Preview

## Changes

- Resolve existing symlinks and real filesystem ancestors before checking whether installation and Vault paths remain inside the current user's home directory.
- Reject install and Vault targets that are identical or nested in either direction.
- Add Node regression tests for symlink escape and overlapping paths.
- Keep the conversational MCP flow and optional MCP Apps panel unchanged.

## Safety boundaries

- No administrator privileges are requested.
- No Agent configuration files are modified.
- No data-source credentials are collected.
- No DingTalk login, subscriptions, historical import, background service, cloud sync or capture is enabled.
- Local SQLite and Vault content remain unencrypted at rest in this preview. Use synthetic/non-sensitive data only.

## Validation

- Node Agent Bridge tests: 9 passed, 0 failed.
- Full Python suites and ontology validators are to be reported in the companion validation report.
- MCP SDK package installation, MCP Inspector protocol handshake, MCP Apps build and real Agent-host validation remain unexecuted because the dependency installation was not completed in this environment.
