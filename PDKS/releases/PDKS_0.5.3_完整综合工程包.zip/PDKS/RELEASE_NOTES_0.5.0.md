# PDKS 0.5.0 — Personal Capture Runtime Architecture & Reference Implementation

## Position

Still an experimental transitional Skill development release. This is a local reference implementation, not a production personal digital foundation platform or Personal Assistant OS.

## Version matrix

- Runtime track: `0.5.0`
- Agent Skill: `0.3.4`
- Personal Capture Runtime: `0.1.0`
- PDKS Standard: `0.1.0` (unchanged)
- JSON Record Schema: `0.1.x` (unchanged)
- Ontology: `0.2.1` (frozen)
- Event Taxonomy: `0.1.0` (unchanged)

## Added

1. Six-layer Personal Capture Runtime architecture.
2. Host-neutral REST/OpenAPI API and Python client.
3. Per-Agent scoped bearer token model (local prototype).
4. Manual text/file ingestion with SHA-256 vault, dedup and idempotency.
5. Source Asset / Evidence Segment generation and provenance.
6. Text extraction for TXT, Markdown, CSV, JSON, HTML, EML, ICS and DOCX.
7. Local consent registry; automatic capture methods are deny-by-default.
8. PDKS JSON Schema validation, source ownership checks and consent propagation.
9. Candidate records and separate owner approval.
10. Local export bundle with SHA-256 verification.
11. Local source deletion with dependent record-body purge.
12. Source registry, runtime installation guide and 26 runtime tests.
13. Skill 0.3.4 runtime integration contract.

## Not implemented / not claimed

- Native DingTalk, WeChat, WeCom, Slack, email, calendar or cloud-drive connectors.
- Live audio capture, ASR, OCR, PDF extraction, video understanding or deep XLSX/PPTX parsing.
- Background microphone, camera, location, desktop or wearable capture.
- Remote/TLS service, cloud relay, multi-device sync or production MCP server.
- Production-grade encryption, KMS, identity, consent, audit or backup deletion.
- Full import/migration into another runtime.

## Validation commands

```bash
python -m unittest discover -s tests -v
python -m unittest discover -s prototype -v
python -m unittest discover -s runtime/tests -v
python skills/pdks-personal-knowledge/scripts/validate_skill_stage.py --json
python prototype/pdks_ontology_cli.py ontology-check
python skills/pdks-personal-knowledge/scripts/build_ontology_manifest.py --check
```

## Safety

Runtime binds to loopback only. Do not expose it publicly. Local SQLite and raw vault are not encrypted. Use non-sensitive synthetic test data until a security-reviewed deployment exists.
