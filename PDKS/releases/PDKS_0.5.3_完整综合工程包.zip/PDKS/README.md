# PDKS — Personal Data Knowledge System

This directory is the dedicated home of the PDKS project within `yixuan2016/creative`.

- Current release: **0.5.3 Node-native Agent Bootstrap Preview**
- Development stage: `transitional_skill_development`
- Maturity: Experimental / Preview
- Ontology baseline: 0.2.1 (frozen)
- Default initialization: Node-native File-first Vault; Python is not required for the initial Vault.

## Contents

The full source tree and documentation are preserved in the release bundle:

- `releases/PDKS_0.5.3_完整综合工程包.zip` — complete project directory (all source, standards, Skills, Runtime, connectors, docs, examples, tests and reports).
- `MANIFEST.json` — per-file SHA-256 inventory for the complete project tree.
- `MANIFEST.sha256` — checksum of the manifest.
- `README.md` — project entrypoint.

The release archive expands to a `PDKS/` project directory with the following top-level layout:

`agent-native/`, `runtime/`, `skills/`, `setup/`, `docs/`, `examples/`, `prototype/`, `reports/`, `tests/`, `.github/`.

## First use

Use a local-capable Agent with local execution enabled. Read `skills/pdks-setup/SKILL.md`. The default workflow is:

`pdks_native_doctor` → `pdks_native_plan` → explicit user approval → `pdks_native_apply` → `pdks_native_verify`.

A cloud-only Agent cannot access local files without an explicitly configured local bridge.

## Safety and maturity

This is an experimental transition-stage release, not production-ready Personal AI Life OS. Initializing a Vault does not connect data sources or start collection. The optional Capture Runtime remains Python-based and separate. Local Vault files are not encrypted at rest; do not use sensitive personal or enterprise data.
