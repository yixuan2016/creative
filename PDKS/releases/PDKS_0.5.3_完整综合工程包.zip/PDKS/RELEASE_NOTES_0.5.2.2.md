# PDKS 0.5.2.2 — Agent-native Bootstrap Preview

Development stage: `transitional_skill_development`  
Maturity: Experimental / Preview

## Added

- Node.js Agent Bridge 0.1.0 with local MCP STDIO server source and CLI.
- MCP tools: `pdks_doctor`, `pdks_bootstrap_plan`, `pdks_bootstrap_apply`, `pdks_verify`, `pdks_vault_status`, `pdks_agent_config_preview`.
- Optional MCP Apps interactive setup wizard source (`pdks_setup_wizard`) with path selection, environment checks, plan review and explicit confirmation.
- MCP Elicitation confirmation form is used when the host advertises that capability; text-only MCP tool flow remains available when it does not.
- Text-only MCP tool flow remains available when a host does not support MCP Apps.
- Generic Agent MCP config preview; no host configuration files are edited.
- Python Bootstrap Engine 0.2.0: user-visible File-first Vault initialization and Ontology 0.2.1 asset seeding.
- Existing PDKS Vault config and ontology files are preserved; only missing defaults are added.
- Exact plan SHA-256, confirmation phrase `CONFIRM INSTALL PDKS`, and explicit unencrypted-storage acknowledgement gate apply.
- Ordinary-user Agent initialization guide and architecture documentation.

## Validation

- Python tests: 47 total, 46 passed, 1 skipped.
- Ontology prototype tests: 33 total, 32 passed, 1 skipped.
- Runtime tests: 64 passed.
- Node Bridge tests: 7 passed.
- Total: 151 tests, 149 passed, 2 skipped, 0 failed.
- Stage validator: 12/12 valid.
- Ontology 0.2.1: valid; 98/98 runtime term coverage; 67 controlled-vocabulary codes; 72 event-taxonomy codes.
- Ontology manifest: 8/8 files valid.
- Python compileall and Node syntax checks: passed.
- Node CLI doctor: 9/9 environment checks passed in the current development environment (Node 22.16.0 / Python 3.13.5).
- Node CLI plan and generic MCP config preview: passed; JSON output parsed successfully.
- File-first Vault initialization helper: passed; ontology assets seeded and user-edited configuration / ontology files preserved.
- Install safety tests: wrong plan hash and missing storage acknowledgement both rejected before mutation.

## Not validated / limitations

- npm registry access timed out in the build environment; MCP SDK dependencies were not installed, and `npm run build` was not executed.
- MCP server protocol round-trip and MCP Apps UI rendering have not been verified with MCP Inspector or a real Agent host.
- ChatGPT, Claude, Cursor, Codex and WorkBuddy host-specific compatibility is not certified.
- Full `pdks_bootstrap_apply` install was not run; it creates a venv and fetches the pinned `jsonschema` binary wheel from PyPI.
- Python 3.10+ is still required by the current Runtime installer; a managed Python runtime is not bundled.
- The Bridge only prints MCP config snippets; it does not edit host configuration files.
- No Node-native Capture Runtime, at-rest encryption, OS Keychain, DWS login, data-source subscription, historical import, background service, cloud sync or remote relay is delivered.

Use synthetic or non-sensitive test data only. SQLite and Vault are not encrypted at rest in this preview.
