# PDKS 0.5.1.2 Release Notes

## Added
- PDKS Setup Skill 0.1.0 for Codex, WorkBuddy and other local-capable Agents.
- PDKS Bootstrap Engine 0.1.0: read-only doctor, deterministic install plan, plan-hash approval, user-level install, verification and non-destructive uninstall preview.
- Windows PowerShell and macOS/Linux setup wrappers.
- Generic Agent adapter notes and L0-L3 confirmation policy.

## Fixed
- DWS event subscription now runs only after PDKS consent, positive DWS authentication, determinate local auth state, exact profile match and event schema checks.
- DWS auth state now fails closed for `reason`, `local_state_requires_repair`, `local_state_unreadable`, invalid token, missing authenticated status, unknown profile and empty schema.
- Installer uses a staging directory and atomic promotion; failed installation cleans only its own staging directory and leaves the final target untouched.

## Preserved
- PDKS Personal Knowledge Skill 0.3.4 unchanged.
- PDKS Ontology 0.2.1 unchanged.
- PDKS Standard 0.1.0 and record schema 0.1.x unchanged.
- Runtime 0.1.1 and DWS Connector 0.1.0; DWS connector code now has stricter preflight checks.

## Limitations
- Python 3.10+ is required; an embedded Python runtime/native MSI/PKG is not included.
- PyPI network access is required to install `jsonschema` wheels.
- Runtime SQLite/Vault are not encrypted at rest; installer requires explicit acknowledgement and data collection remains disabled.
- DWS installation/OAuth, historical import, background service, auto-start, cloud backup and Agent-specific Skill directory changes are separate, not implemented in Bootstrap Engine 0.1.0.
- Real Codex/WorkBuddy host integration and real DingTalk tenant event delivery have not been executed in this environment.
