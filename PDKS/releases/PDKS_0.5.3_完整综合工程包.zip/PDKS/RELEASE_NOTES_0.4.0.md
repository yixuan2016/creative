# Release Notes — PDKS 0.4.0

## 主题：Ontology-first 个人数据运行时

### 新增
- 模块化 PDKS Ontology 0.2.0：Core、Governance、Agent Runtime。
- 受控词汇 0.2.0、SHACL Shapes、JSON-LD Context、JSON→Ontology Mapping、0.1→0.2 迁移表。
- 稳定术语命名空间 `urn:pdks:ontology#`，并提供 legacy 0.1 等价桥接。
- OntologyRuntime：JSON Schema / Taxonomy / Ontology profile 校验与 RDF 投影。
- OntologySQLiteStore：canonical records、不可变版本、owner revision、Ontology Registry、RDF triples、metadata audit。
- CLI：ontology-info、validate、init、import、list、export、rebuild、revision、sparql。
- PDKS Skill 0.3.0：新增 ontology-first 语义规则和可携带运行时脚本。

### 设计决策
- SQLite 继续作为本地权威持久化层；RDF 是可重建语义视图。
- Record Schema 0.1.x 保持兼容；Ontology 升级不强制重写历史 JSON。
- 原始文件独立存储；数据库保存 locator、hash 和证据定位。
- Ontology 不等于访问控制；Consent / Policy 必须由可信运行时服务执行。
- Intent 与 Agent Action Proposal 分离；Assertion 不等于事实；Event 不等于 Assertion。

### 验证
- 自动化测试：20/20 通过。
- 示例数据：29 条记录、3 个 owner 分区、严格引用校验通过。
- Turtle：9 个文件、2,187 triples 语法解析通过。
- Event Taxonomy：72 个事件类型概念。
- 受控词汇：67 个概念代码。
- SQLite 持久化、重启恢复、幂等、owner 隔离、并发冲突、版本更新、RDF 导出、SPARQL 和重建测试通过。

### 未完成 / 不宣称
- pySHACL 未安装，SHACL runtime 未执行。
- 数据库加密、密钥管理、owner 身份认证、正式 Consent / Policy Service 未实现。
- 钉钉/录音连接器、多端同步、原始文件物理删除传播、生产级防篡改审计未实现。
- 没有真实用户数据抽取精度或跨模型一致性基准。
