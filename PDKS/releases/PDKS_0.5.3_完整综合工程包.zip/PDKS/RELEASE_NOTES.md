# PDKS Release Notes Index

## Current release: 0.5.1 — Official DWS CLI Connector Reference Implementation

See [`RELEASE_NOTES_0.5.1.md`](RELEASE_NOTES_0.5.1.md) and [`reports/PDKS_0.5.1_VALIDATION_REPORT.md`](reports/PDKS_0.5.1_VALIDATION_REPORT.md).

This remains an Experimental / Preview release in the transitional Skill development stage. The PDKS Skill 0.3.4, PDKS Standard 0.1.0, Record Schema 0.1.x, Ontology 0.2.1 and Event Taxonomy 0.1.0 remain unchanged.

## Previous releases

- `RELEASE_NOTES_0.5.0.md` — Personal Capture Runtime architecture and local reference implementation.
- `RELEASE_NOTES_0.4.3.md` — Cross-Agent Skill validation edition.
- `RELEASE_NOTES_0.4.2.md` — Transitional Skill engineering boundary.
- `RELEASE_NOTES_0.4.1.md` — Ontology quality gates and semantic governance.
- `RELEASE_NOTES_0.4.0.md` — Ontology-first architecture.
- `RELEASE_NOTES_0.3.0.md` — Earlier Skill baseline.
