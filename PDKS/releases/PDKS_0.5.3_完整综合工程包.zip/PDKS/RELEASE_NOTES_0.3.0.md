# PDKS × ADS Personal Runtime 0.3.0 Release Notes

## 本次目标
将 PDKS Agent Skill 0.2.0 的结构化记录接入 ADS-WORK-09 个人运行时，验证本地持久化与跨标准映射闭环。

## 新增能力
- SQLite 本地持久化：Events、Memories、Intents、Agent Actions、Suppressed Sources。
- owner 分区和 revision 乐观并发控制。
- 原子事务、幂等写入和稳定 ID。
- 元数据级 append-only 审计日志，避免将记录正文复制到审计表。
- 一致性备份和 SQLite integrity_check。
- PDKS JSON Schema 与 Event Taxonomy 默认校验。
- PDKS Event → ADS Personal Event Ledger 映射。
- PDKS Knowledge Asset / Personal Context → candidate Memory 映射。
- PDKS Action → candidate Intent 映射；不自动创建 Agent Action Proposal。
- device_capture / connector_sync 授权引用门禁。
- CLI：init、project-pdks、apply-projection、context、audit、backup、integrity-check、snapshot。
- 来源 suppression 后撤回派生 Memory、暂停依赖 Intent 并要求 owner review。
- 新增本地持久化与映射测试。

## 保持不变
- PDKS 数据标准仍为 0.1.0。
- PDKS Agent Skill 仍为 0.2.0。
- ADS-WORK-08 / ADS-WORK-09 / ADS-WORK-10 的既有职责边界不变。
- 个人数据默认 personal_only；不自动创建企业投影。

## 本地验证结果
- 33 项运行时测试：32 项通过，1 项因独立包未包含 ADS Schema 而跳过；另有 5 项 Skill 发布冒烟测试全部通过；完整 `creative` 仓库中该 Schema 联合测试会执行。
- CLI 端到端测试：手工导入模式下完成 1 Event + 2 candidate Memory + 1 candidate Intent 的投影、持久化、上下文构建、审计、备份和完整性检查。
- SQLite integrity_check：ok。

## 未完成 / 不作生产能力声明
- 数据库静态加密、密钥管理和 owner 身份认证。
- 正式 Consent / Policy Service 与连接器授权服务。
- 钉钉、录音设备、邮件、日历真实连接器。
- 多端同步、冲突合并和授权撤回传播。
- 原始来源、备份和派生数据的物理删除闭环。
- 生产级审计防篡改、压力测试和真实数据准确率评估。
