# PDKS 0.5.2 — File-first Storage Architecture Baseline

Status: architecture baseline / preview. Not a production file-store release.

## Added
- File-first storage decision record.
- Portable Vault directory convention.
- Markdown + YAML Frontmatter knowledge-note contract.
- JSON / JSONL source-evidence contract.
- SHA-256 content-addressed original attachments.
- SQLite rebuildable-index role.
- Direct Obsidian Vault viewing strategy.
- Synthetic sample Vault for compatibility inspection.

## Not yet implemented
- Production File Store Adapter.
- Complete SQLite index rebuild from files.
- Atomic reconciliation and conflict recovery for all data classes.
- Encrypted Vault and OS-keychain integration.
- Obsidian plugin.
- Multi-device sync.
- Full migration from the current SQLite/blob runtime.

## Compatibility promise
The canonical storage contract remains open-format and Agent-independent. Obsidian is an optional viewer/editor, not a runtime dependency.
