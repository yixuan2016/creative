# PDKS 0.5.1 — Official DWS CLI Connector Reference Implementation

## Position

Still an experimental transitional Skill development release. It is not a production personal digital foundation platform or Personal Assistant OS.

## Version matrix

- Runtime track: `0.5.1`
- Agent Skill: `0.3.4` (unchanged)
- Personal Capture Runtime: `0.1.1`
- DWS Connector: `0.1.0`
- PDKS Standard: `0.1.0` (unchanged)
- Record Schema: `0.1.x` (unchanged)
- Ontology: `0.2.1` (frozen)
- Event Taxonomy: `0.1.0` (unchanged)

## Added

1. Official DWS CLI wrapper using safe subprocess argument arrays (`shell=False`).
2. Read-only DWS version and OAuth status checks.
3. Explicit DWS profile selection and preflight mismatch checks.
4. Catalog of 33 documented public personal event keys.
5. Read-only event schema and reviewed read-only command schema discovery.
6. NDJSON event stream process management, ready-marker parsing, subscription ID capture and graceful stop.
7. Event-to-PDKS Source Asset mapping with source locator, profile, event key, content hash, stable ID and idempotency.
8. Mandatory PDKS Consent validation for DWS `system_sync` capture.
9. Explicit AI minutes summary retrieval using `dws minutes get summary --id <task_uuid>`.
10. Runtime `get_capture` response now exposes more source provenance fields.
11. Foreground DWS event stream consumer with graceful stop; background service manager, auto-restart and persistent cursor are deferred.
12. 26 DWS Connector automated tests using simulated CLI and event streams.
13. DWS Connector architecture report in Markdown, HTML and DOCX.

## Not implemented / not verified

- No live DWS CLI installation or authenticated user profile in the development container.
- Real tenant event delivery and per-event enablement are not verified.
- Historical query pagination/backfill is not implemented; only read-only command schema discovery exists.
- Full minutes transcription, media downloads and attachment enrichment are not implemented.
- No native ChatGPT/Claude/Codex/Cursor host adapters, remote relay, production encryption or multi-device sync.
- No PDKS Standard, JSON Schema, Ontology or Event Taxonomy version changes.

## Validation

- Skill regression: 39 tests (38 passed, 1 skipped)
- ADS / personal runtime regression: 33 tests (32 passed, 1 skipped)
- Capture Runtime + DWS Connector: 53 tests (53 passed)
- Aggregate: 125 tests (123 passed, 2 skipped, 0 failed)
- Stage validator: 12/12 valid
- Ontology 0.2.1: valid; 98/98 runtime terms referenced/declared
- Ontology manifest: 8/8 files valid
- Runtime compile check: passed

The two skipped tests are SHACL tests skipped because pySHACL is not installed in this local environment. The GitHub Actions workflow has not been executed for this release.

## Safety

DWS access requires DWS OAuth login and tenant CLI access permission. PDKS separately requires an active DWS/work Consent Grant. Broad direct/group message subscriptions must be explicitly selected. Connector exposes no DWS business write commands. Use a small `--max-events` trial first.
